=============================
PDProcessor
=============================

.. image:: https://badge.fury.io/py/pdprocessor.png
    :target: http://badge.fury.io/py/pdprocessor

.. image:: https://travis-ci.org/jasonwadejob@gmail.com/pdprocessor.png?branch=master
    :target: https://travis-ci.org/jasonwadejob@gmail.com/pdprocessor

A project that uses pandas to process delimited files.


Features
--------

* TODO

